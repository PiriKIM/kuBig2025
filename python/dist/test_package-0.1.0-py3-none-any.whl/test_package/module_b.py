module_var_b = "b 모듈의 변수이다!"

class Module_B:
    def __str__(self):
        return "Module B의 객체"