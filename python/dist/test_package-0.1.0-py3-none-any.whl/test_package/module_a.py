module_var_a = "a 모듈의 변수이다!"

def module_a_func():
    print("a 모듈의 함수가 실행되었다!!")
